/* 
 * File:   main.cpp
 * Author: Michael Walter
 * Course: 42829, Program Logic Using C++
 *Purpose: (Netbeans)Setup Homework
 * Created on February 21, 2016, 8:47 PM
 */

// System Libraries
#include <iostream>

using namespace std;

// Outputs Hello World
int main() {
    
    cout << "Hello World!" << endl;
    
    return 0;
}

